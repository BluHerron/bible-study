# Bible Study Web App

A personal Bible study web app with Theographic Bible metadata integration and AI-assisted search.

## Deploy with GitHub Pages

1. Create a new **public** GitHub repository (for example, `bible-study`).
2. Upload the contents of this project to the repository's root. Make sure `index.html`, `theographic-data/`, and `.github/` are at the top level.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **GitHub Actions** as the source.
5. Push to the `main` branch, or run the **Deploy Bible Study to GitHub Pages** workflow from the Actions tab.

The included workflow deploys the site automatically whenever you push to `main`.

## Local testing

Because the app loads JSON files with `fetch`, run it from a local web server rather than opening `index.html` directly with `file://`:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Data

The `theographic-data/` directory contains the Theographic JSON datasets used by the app. See `THEOGRAPHIC-LICENSE.txt` for the applicable license.
